var blkdev_8h =
[
    [ "blkdev", "structblkdev.html", "structblkdev" ],
    [ "blkdev_ops", "structblkdev__ops.html", "structblkdev__ops" ],
    [ "BLOCK_SIZE", "blkdev_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba289ec7492eb0ef6bf5285fb142203e11", null ],
    [ "SUCCESS", "blkdev_8h.html#adf764cbdea00d65edcd07bb9953ad2b7ac7f69f7c9e5aea9b8f54cf02870e2bf8", null ],
    [ "E_BADADDR", "blkdev_8h.html#adf764cbdea00d65edcd07bb9953ad2b7af16881b24ad80d10c743eda36cf960be", null ],
    [ "E_UNAVAIL", "blkdev_8h.html#adf764cbdea00d65edcd07bb9953ad2b7a2c02b86c7aeaec4d298b3332b698090f", null ],
    [ "E_SIZE", "blkdev_8h.html#adf764cbdea00d65edcd07bb9953ad2b7a14cfcdfcfc960a98f036ab1f672c0ff0", null ]
];