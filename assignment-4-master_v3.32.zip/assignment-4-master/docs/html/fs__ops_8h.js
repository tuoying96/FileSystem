var fs__ops_8h =
[
    [ "fs_chmod", "fs__ops_8h.html#a75fd55ba2a5ce1547de76ad0ea02953c", null ],
    [ "fs_getattr", "fs__ops_8h.html#a2946ed746d7476c349073bd9545e54a3", null ],
    [ "fs_init", "fs__ops_8h.html#a5088753958939f71726c1f53c3201090", null ],
    [ "fs_mkdir", "fs__ops_8h.html#a29c56b3e482c6294d5e78bd5888f1055", null ],
    [ "fs_mknod", "fs__ops_8h.html#a64d48a26c224e6cccdc4fabc145ac105", null ],
    [ "fs_open", "fs__ops_8h.html#a55e097f4bb152622731c3abe3827ccf5", null ],
    [ "fs_opendir", "fs__ops_8h.html#a46e1751b51e02660137174b725c60944", null ],
    [ "fs_read", "fs__ops_8h.html#a23d4777782c69635acc801483a3fb55f", null ],
    [ "fs_readdir", "fs__ops_8h.html#a6179a6ad90011d3fea4d88dff964723e", null ],
    [ "fs_release", "fs__ops_8h.html#a53d64358ada4f68ae09adc49555504f9", null ],
    [ "fs_releasedir", "fs__ops_8h.html#a0279a57dff80008b9bd24cd72af33510", null ],
    [ "fs_rename", "fs__ops_8h.html#a94387b4510bd5c3606afa272caf27bd7", null ],
    [ "fs_rmdir", "fs__ops_8h.html#a3995e30879be02abd9624ddc5f091681", null ],
    [ "fs_statfs", "fs__ops_8h.html#ae9834fdcbcc9aba67aa330dae6a27bfb", null ],
    [ "fs_truncate", "fs__ops_8h.html#addd31e83c1aadf602748e3eec5105e25", null ],
    [ "fs_unlink", "fs__ops_8h.html#ab979f963a8372f98080f66e0f32c8df6", null ],
    [ "fs_utime", "fs__ops_8h.html#abd875ce6059fa9436edbe5b442687759", null ],
    [ "fs_write", "fs__ops_8h.html#a82580487f183c37b5ab5c894ef71ef6c", null ]
];