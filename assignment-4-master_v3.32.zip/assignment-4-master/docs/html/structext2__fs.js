var structext2__fs =
[
    [ "block_map", "structext2__fs.html#a2c8f1da676b43b769185d47ea830e411", null ],
    [ "block_map_base", "structext2__fs.html#aaafa8984eed7a5a51ebc996a907eebde", null ],
    [ "dirty", "structext2__fs.html#acad6240bd43452521daf96a7c4bec83e", null ],
    [ "inode_base", "structext2__fs.html#a0ddcc30593edb8a2fbb2e4e5055fbc5d", null ],
    [ "inode_map", "structext2__fs.html#a35d2a1167329f39eb72f83746e9b8360", null ],
    [ "inode_map_base", "structext2__fs.html#aef79410fa076c7bbe8d677e6a27f0546", null ],
    [ "inodes", "structext2__fs.html#acb0a1cfb341064e4b6e6756ee3e76539", null ],
    [ "n_blocks", "structext2__fs.html#a19b0be218a3fca62f8e8cc4c218f199b", null ],
    [ "n_inodes", "structext2__fs.html#ad74e735e3d50b1967ba56e4a95b969d3", null ],
    [ "n_meta", "structext2__fs.html#ad9f361db19163fdafb6a056d269b5520", null ],
    [ "root_inode", "structext2__fs.html#a84b696c1f2ec0c6224d7957f2b952ccb", null ]
];