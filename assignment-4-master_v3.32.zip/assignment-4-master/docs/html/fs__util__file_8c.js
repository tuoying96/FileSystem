var fs__util__file_8c =
[
    [ "do_mkentry", "fs__util__file_8c.html#a42a9da4174da36d26072697fa4960234", null ],
    [ "do_read", "fs__util__file_8c.html#ac58a385f4bb1e917cb9041bb572ebdcb", null ],
    [ "do_rename", "fs__util__file_8c.html#a58f64199b1eec2d34b3d30238b36a151", null ],
    [ "do_stat", "fs__util__file_8c.html#acfbafc0a9296ed1095e6b7e380cde81b", null ],
    [ "do_truncate", "fs__util__file_8c.html#ac29ef40ab407c8daee03ed1d3e387dac", null ],
    [ "do_unlink", "fs__util__file_8c.html#afc6a035c3c18ed84b644908198680db3", null ],
    [ "do_write", "fs__util__file_8c.html#af449bfd3b984ef01449b6b70f9149317", null ],
    [ "get_file_blk", "fs__util__file_8c.html#ae093a93624f9f341aec41d764dd291f0", null ],
    [ "get_file_blkno", "fs__util__file_8c.html#aeef70c40bc20fc1541879f9d90340724", null ],
    [ "init_new_inode", "fs__util__file_8c.html#aa50635cdc05634f43907a2cf8bd910e1", null ]
];