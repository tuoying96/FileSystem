var fs__op__truncate_8c =
[
    [ "fs_truncate", "fs__op__truncate_8c.html#addd31e83c1aadf602748e3eec5105e25", null ]
];