var structfs__inode =
[
    [ "ctime", "structfs__inode.html#abc51dbf14b1ed14555205403a1b5135c", null ],
    [ "direct", "structfs__inode.html#aaa19c11f289348eebe1ec918ea4e800a", null ],
    [ "gid", "structfs__inode.html#a93b1c3bdde3437a4dbfe538ffe47dc01", null ],
    [ "indir_1", "structfs__inode.html#a9e5a9c0438bed928f8cc8111168857e2", null ],
    [ "indir_2", "structfs__inode.html#a0057efb762c101eab65d4be934e7c8a4", null ],
    [ "mode", "structfs__inode.html#a792b925ece998fe1fc522d285d32a9b2", null ],
    [ "mtime", "structfs__inode.html#ab11566bfc13bcd9f7cf24121447b0cfd", null ],
    [ "nlink", "structfs__inode.html#a175dfc8cdb7f6b5f0fe4b9a2c34ff4e9", null ],
    [ "pad", "structfs__inode.html#a3e12e5d3d93abd6a8f2ca80f68ceaeff", null ],
    [ "size", "structfs__inode.html#ac10de2ad4b7c87da65fc17b5674b5759", null ],
    [ "uid", "structfs__inode.html#ada0d9d68adb122d7e83558a1b8f683ec", null ]
];