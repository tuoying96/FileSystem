var structfs__dirent =
[
    [ "inode", "structfs__dirent.html#a466a010b7eed4ff1ec85935b085a985c", null ],
    [ "isDir", "structfs__dirent.html#a1c3a5b57fd9c3f75e966c3d91903216e", null ],
    [ "name", "structfs__dirent.html#af7c804dadcb775b4dc65c820b5639d6b", null ],
    [ "valid", "structfs__dirent.html#ac18077e9015176ebe00d8ed141908985", null ]
];