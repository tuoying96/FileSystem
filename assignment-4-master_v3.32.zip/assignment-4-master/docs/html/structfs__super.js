var structfs__super =
[
    [ "block_map_sz", "structfs__super.html#a6d61e3b48439ba04327070b063a8a10d", null ],
    [ "inode_map_sz", "structfs__super.html#a1e20b28ed103f32c2dc32be1f1deac2f", null ],
    [ "inode_region_sz", "structfs__super.html#a2b0e4d3ef8abb772c2420275ff7b7180", null ],
    [ "magic", "structfs__super.html#afeb574f7842616be46cbcb74b7b9052b", null ],
    [ "num_blocks", "structfs__super.html#ab8e870f2a8b20a7a648c45c7a68562a3", null ],
    [ "pad", "structfs__super.html#af65f848f97a1bbae420ec3b50068281d", null ],
    [ "root_inode", "structfs__super.html#a92d040f07d12e443697b6017e190d994", null ]
];