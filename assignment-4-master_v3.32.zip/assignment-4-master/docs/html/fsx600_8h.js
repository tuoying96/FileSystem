var fsx600_8h =
[
    [ "fs_dirent", "structfs__dirent.html", "structfs__dirent" ],
    [ "fs_super", "structfs__super.html", "structfs__super" ],
    [ "fs_inode", "structfs__inode.html", "structfs__inode" ],
    [ "FS_BLOCK_SIZE", "fsx600_8h.html#a99fb83031ce9923c84392b4e92f956b5adcb14898e7908b801bb1d28c8f2d7c62", null ],
    [ "FS_MAGIC", "fsx600_8h.html#a99fb83031ce9923c84392b4e92f956b5a7418fc3e666a96b78bec5db2cbfb9b4b", null ],
    [ "FS_FILENAME_SIZE", "fsx600_8h.html#abc6126af1d45847bc59afa0aa3216b04ac1fcd5a8998df86a4b97e165c81f704a", null ],
    [ "N_DIRECT", "fsx600_8h.html#adc29c2ff13d900c2f185ee95427fb06ca4f2dcb63f06cc38f47272e416b198859", null ],
    [ "DIRENTS_PER_BLK", "fsx600_8h.html#a61dadd085c1777f559549e05962b2c9ea35291575fc9d91058934110dde5c0ad5", null ],
    [ "INODES_PER_BLK", "fsx600_8h.html#a61dadd085c1777f559549e05962b2c9eae92db5d7d963bb87bd6205d71dd2cf4f", null ],
    [ "PTRS_PER_BLK", "fsx600_8h.html#a61dadd085c1777f559549e05962b2c9ea6c2e35c902333d60f68723f33ef5ddfe", null ],
    [ "BITS_PER_BLK", "fsx600_8h.html#a61dadd085c1777f559549e05962b2c9eac676a6e35862d6b48f75cefd145010f4", null ]
];