var structimage__dev =
[
    [ "fd", "structimage__dev.html#a7990ec13527bc09b7001cd3c8521d6a5", null ],
    [ "nblks", "structimage__dev.html#acfffdc9f27b19b77eba17072740369b8", null ],
    [ "path", "structimage__dev.html#a83978c4c6650249e48af128d591d4826", null ]
];