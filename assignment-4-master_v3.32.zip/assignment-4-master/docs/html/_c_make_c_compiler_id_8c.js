var _c_make_c_compiler_id_8c =
[
    [ "ARCHITECTURE_ID", "_c_make_c_compiler_id_8c.html#aba35d0d200deaeb06aee95ca297acb28", null ],
    [ "C_DIALECT", "_c_make_c_compiler_id_8c.html#a07f8e5783674099cd7f5110e22a78cdb", null ],
    [ "COMPILER_ID", "_c_make_c_compiler_id_8c.html#a81dee0709ded976b2e0319239f72d174", null ],
    [ "DEC", "_c_make_c_compiler_id_8c.html#ad1280362da42492bbc11aa78cbf776ad", null ],
    [ "HEX", "_c_make_c_compiler_id_8c.html#a46d5d95daa1bef867bd0179594310ed5", null ],
    [ "PLATFORM_ID", "_c_make_c_compiler_id_8c.html#adbc5372f40838899018fadbc89bd588b", null ],
    [ "STRINGIFY", "_c_make_c_compiler_id_8c.html#a43e1cad902b6477bec893cb6430bd6c8", null ],
    [ "STRINGIFY_HELPER", "_c_make_c_compiler_id_8c.html#a2ae9b72bb13abaabfcf2ee0ba7d3fa1d", null ],
    [ "main", "_c_make_c_compiler_id_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "info_arch", "_c_make_c_compiler_id_8c.html#a59647e99d304ed33b15cb284c27ed391", null ],
    [ "info_compiler", "_c_make_c_compiler_id_8c.html#a4b0efeb7a5d59313986b3a0390f050f6", null ],
    [ "info_language_dialect_default", "_c_make_c_compiler_id_8c.html#a1ce162bad2fe6966ac8b33cc19e120b8", null ],
    [ "info_platform", "_c_make_c_compiler_id_8c.html#a2321403dee54ee23f0c2fa849c60f7d4", null ]
];