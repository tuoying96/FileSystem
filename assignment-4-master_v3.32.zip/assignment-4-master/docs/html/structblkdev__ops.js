var structblkdev__ops =
[
    [ "close", "structblkdev__ops.html#abb37982386a2ac5e5a2245c9eed0729e", null ],
    [ "flush", "structblkdev__ops.html#a116088333992c2d4cb3b1b5fc22a0995", null ],
    [ "num_blocks", "structblkdev__ops.html#a89a611add981f41f4b212acd35454ac9", null ],
    [ "read", "structblkdev__ops.html#aa61f7809c156ca109a14d9b878ce95af", null ],
    [ "write", "structblkdev__ops.html#a94de8648f5e486f9fd7217ffa3073964", null ]
];