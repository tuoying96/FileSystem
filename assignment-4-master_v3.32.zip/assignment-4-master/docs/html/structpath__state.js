var structpath__state =
[
    [ "idx", "structpath__state.html#af204ae03127ab7dc51a2ff44b865c53f", null ],
    [ "inum", "structpath__state.html#a51451cdd9a2e6707248101568c333662", null ],
    [ "noleaf", "structpath__state.html#a57a88aa34b6e7df89f56c0137b8b811f", null ],
    [ "pathlen", "structpath__state.html#a197208f3661d2f897da8f4e81cfe6f94", null ],
    [ "pathtoks", "structpath__state.html#af6f9ab34369f9b477a66a04ad9c8b5d5", null ],
    [ "symcount", "structpath__state.html#a238bb91cb3a70a7e5e61958a26e36684", null ]
];