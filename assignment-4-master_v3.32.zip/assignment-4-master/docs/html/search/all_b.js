var searchData=
[
  ['n_5fblocks',['n_blocks',['../structext2__fs.html#a19b0be218a3fca62f8e8cc4c218f199b',1,'ext2_fs']]],
  ['n_5fdirect',['N_DIRECT',['../fsx600_8h.html#adc29c2ff13d900c2f185ee95427fb06ca4f2dcb63f06cc38f47272e416b198859',1,'fsx600.h']]],
  ['n_5finodes',['n_inodes',['../structext2__fs.html#ad74e735e3d50b1967ba56e4a95b969d3',1,'ext2_fs']]],
  ['n_5fmeta',['n_meta',['../structext2__fs.html#ad9f361db19163fdafb6a056d269b5520',1,'ext2_fs']]],
  ['name',['name',['../structfs__dirent.html#af7c804dadcb775b4dc65c820b5639d6b',1,'fs_dirent::name()'],['../structfuse__cmds.html#a9ecdb123f41657e4da23723541b5fe75',1,'fuse_cmds::name()']]],
  ['nargs',['nargs',['../structfuse__cmds.html#a92d565e429f444d8ddf9055538d0655d',1,'fuse_cmds']]],
  ['nblks',['nblks',['../structimage__dev.html#acfffdc9f27b19b77eba17072740369b8',1,'image_dev']]],
  ['next_5fptr',['next_ptr',['../mktest_8c.html#a1f6cf6dd8210fc8d2e95b15f53d0c838',1,'mktest.c']]],
  ['nlink',['nlink',['../structfs__inode.html#a175dfc8cdb7f6b5f0fe4b9a2c34ff4e9',1,'fs_inode']]],
  ['noleaf',['noleaf',['../structpath__state.html#a57a88aa34b6e7df89f56c0137b8b811f',1,'path_state']]],
  ['num_5fblocks',['num_blocks',['../structblkdev__ops.html#a89a611add981f41f4b212acd35454ac9',1,'blkdev_ops::num_blocks()'],['../structfs__super.html#ab8e870f2a8b20a7a648c45c7a68562a3',1,'fs_super::num_blocks()']]]
];
