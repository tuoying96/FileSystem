var searchData=
[
  ['fs_5fblock_5fsize',['FS_BLOCK_SIZE',['../fsx600_8h.html#a99fb83031ce9923c84392b4e92f956b5adcb14898e7908b801bb1d28c8f2d7c62',1,'fsx600.h']]],
  ['fs_5ffilename_5fsize',['FS_FILENAME_SIZE',['../fsx600_8h.html#abc6126af1d45847bc59afa0aa3216b04ac1fcd5a8998df86a4b97e165c81f704a',1,'fsx600.h']]],
  ['fs_5fmagic',['FS_MAGIC',['../fsx600_8h.html#a99fb83031ce9923c84392b4e92f956b5a7418fc3e666a96b78bec5db2cbfb9b4b',1,'fsx600.h']]]
];
