var searchData=
[
  ['image_5fdev',['image_dev',['../structimage__dev.html',1,'']]]
];
