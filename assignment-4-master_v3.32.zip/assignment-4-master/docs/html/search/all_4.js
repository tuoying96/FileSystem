var searchData=
[
  ['dec',['DEC',['../_c_make_c_compiler_id_8c.html#ad1280362da42492bbc11aa78cbf776ad',1,'CMakeCCompilerId.c']]],
  ['direct',['direct',['../structfs__inode.html#aaa19c11f289348eebe1ec918ea4e800a',1,'fs_inode']]],
  ['dirents_5fper_5fblk',['DIRENTS_PER_BLK',['../fsx600_8h.html#a61dadd085c1777f559549e05962b2c9ea35291575fc9d91058934110dde5c0ad5',1,'fsx600.h']]],
  ['dirty',['dirty',['../structext2__fs.html#acad6240bd43452521daf96a7c4bec83e',1,'ext2_fs']]],
  ['disk',['disk',['../misc_8c.html#a02b9597d2639b0bf20dd70c92a5326d0',1,'disk():&#160;misc.c'],['../fs__util__vol_8h.html#a02b9597d2639b0bf20dd70c92a5326d0',1,'disk():&#160;misc.c'],['../mkfs-x6_8c.html#ab93be52ad8f7b2c6f18612931d027a66',1,'disk():&#160;mkfs-x6.c'],['../mktest_8c.html#ab93be52ad8f7b2c6f18612931d027a66',1,'disk():&#160;mktest.c']]],
  ['div_5fround_5fup',['DIV_ROUND_UP',['../mkfs-x6_8c.html#a835db58e5408054455795a9e11b6e387',1,'mkfs-x6.c']]],
  ['do_5fls1',['do_ls1',['../misc_8c.html#a1b17f35d257c44feb91217c24cc9769f',1,'misc.c']]],
  ['do_5fmkentry',['do_mkentry',['../fs__util__file_8c.html#a42a9da4174da36d26072697fa4960234',1,'do_mkentry(int dir_inum, const char *leaf, mode_t mode, unsigned ftype):&#160;fs_util_file.c'],['../fs__util__file_8h.html#a42a9da4174da36d26072697fa4960234',1,'do_mkentry(int dir_inum, const char *leaf, mode_t mode, unsigned ftype):&#160;fs_util_file.c']]],
  ['do_5fread',['do_read',['../fs__util__file_8c.html#ac58a385f4bb1e917cb9041bb572ebdcb',1,'do_read(int inum, char *buf, size_t len, off_t offset):&#160;fs_util_file.c'],['../fs__util__file_8h.html#ac58a385f4bb1e917cb9041bb572ebdcb',1,'do_read(int inum, char *buf, size_t len, off_t offset):&#160;fs_util_file.c']]],
  ['do_5frename',['do_rename',['../fs__util__file_8c.html#a58f64199b1eec2d34b3d30238b36a151',1,'do_rename(int srcdir_inum, const char *src_leaf, int dstdir_inum, const char *dst_leaf):&#160;fs_util_file.c'],['../fs__util__file_8h.html#a58f64199b1eec2d34b3d30238b36a151',1,'do_rename(int srcdir_inum, const char *src_leaf, int dstdir_inum, const char *dst_leaf):&#160;fs_util_file.c']]],
  ['do_5frmdir',['do_rmdir',['../fs__util__dir_8c.html#add655fc4130560c94f6c215cc4135102',1,'do_rmdir(int dir_inum, const char *leaf):&#160;fs_util_dir.c'],['../fs__util__dir_8h.html#add655fc4130560c94f6c215cc4135102',1,'do_rmdir(int dir_inum, const char *leaf):&#160;fs_util_dir.c']]],
  ['do_5fstat',['do_stat',['../fs__util__file_8c.html#acfbafc0a9296ed1095e6b7e380cde81b',1,'do_stat(int inum, struct stat *sb):&#160;fs_util_file.c'],['../fs__util__file_8h.html#acfbafc0a9296ed1095e6b7e380cde81b',1,'do_stat(int inum, struct stat *sb):&#160;fs_util_file.c']]],
  ['do_5ftruncate',['do_truncate',['../fs__util__file_8c.html#ac29ef40ab407c8daee03ed1d3e387dac',1,'do_truncate(int inum, int len):&#160;fs_util_file.c'],['../fs__util__file_8h.html#ac29ef40ab407c8daee03ed1d3e387dac',1,'do_truncate(int inum, int len):&#160;fs_util_file.c']]],
  ['do_5funlink',['do_unlink',['../fs__util__file_8c.html#afc6a035c3c18ed84b644908198680db3',1,'do_unlink(int dir_inum, const char *leaf):&#160;fs_util_file.c'],['../fs__util__file_8h.html#afc6a035c3c18ed84b644908198680db3',1,'do_unlink(int dir_inum, const char *leaf):&#160;fs_util_file.c']]],
  ['do_5fwrite',['do_write',['../fs__util__file_8c.html#af449bfd3b984ef01449b6b70f9149317',1,'do_write(int inum, const char *buf, size_t len, off_t offset):&#160;fs_util_file.c'],['../fs__util__file_8h.html#af449bfd3b984ef01449b6b70f9149317',1,'do_write(int inum, const char *buf, size_t len, off_t offset):&#160;fs_util_file.c']]]
];
