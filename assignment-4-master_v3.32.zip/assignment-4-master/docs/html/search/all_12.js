var searchData=
[
  ['write',['write',['../structblkdev__ops.html#a94de8648f5e486f9fd7217ffa3073964',1,'blkdev_ops']]]
];
