var searchData=
[
  ['direct',['direct',['../structfs__inode.html#aaa19c11f289348eebe1ec918ea4e800a',1,'fs_inode']]],
  ['dirty',['dirty',['../structext2__fs.html#acad6240bd43452521daf96a7c4bec83e',1,'ext2_fs']]],
  ['disk',['disk',['../misc_8c.html#a02b9597d2639b0bf20dd70c92a5326d0',1,'disk():&#160;misc.c'],['../fs__util__vol_8h.html#a02b9597d2639b0bf20dd70c92a5326d0',1,'disk():&#160;misc.c'],['../mkfs-x6_8c.html#ab93be52ad8f7b2c6f18612931d027a66',1,'disk():&#160;mkfs-x6.c'],['../mktest_8c.html#ab93be52ad8f7b2c6f18612931d027a66',1,'disk():&#160;mktest.c']]]
];
