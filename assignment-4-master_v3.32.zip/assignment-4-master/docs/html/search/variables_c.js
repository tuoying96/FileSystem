var searchData=
[
  ['size',['size',['../structfs__inode.html#ac10de2ad4b7c87da65fc17b5674b5759',1,'fs_inode']]],
  ['symcount',['symcount',['../structpath__state.html#a238bb91cb3a70a7e5e61958a26e36684',1,'path_state']]]
];
