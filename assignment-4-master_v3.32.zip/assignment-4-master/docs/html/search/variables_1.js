var searchData=
[
  ['close',['close',['../structblkdev__ops.html#abb37982386a2ac5e5a2245c9eed0729e',1,'blkdev_ops']]],
  ['ctime',['ctime',['../structfs__inode.html#abc51dbf14b1ed14555205403a1b5135c',1,'fs_inode']]]
];
