var searchData=
[
  ['magic',['magic',['../structfs__super.html#afeb574f7842616be46cbcb74b7b9052b',1,'fs_super']]],
  ['mode',['mode',['../structfs__inode.html#a792b925ece998fe1fc522d285d32a9b2',1,'fs_inode']]],
  ['mtime',['mtime',['../structfs__inode.html#ab11566bfc13bcd9f7cf24121447b0cfd',1,'fs_inode']]]
];
