var searchData=
[
  ['read',['read',['../structblkdev__ops.html#aa61f7809c156ca109a14d9b878ce95af',1,'blkdev_ops']]],
  ['root_5finode',['root_inode',['../structfs__super.html#a92d040f07d12e443697b6017e190d994',1,'fs_super::root_inode()'],['../structext2__fs.html#a84b696c1f2ec0c6224d7957f2b952ccb',1,'ext2_fs::root_inode()']]]
];
