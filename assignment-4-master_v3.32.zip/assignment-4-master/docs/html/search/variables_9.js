var searchData=
[
  ['ops',['ops',['../structblkdev.html#a1b85c90a21de8501bf345a78d301cbcb',1,'blkdev']]]
];
