var searchData=
[
  ['uid',['uid',['../structfs__inode.html#ada0d9d68adb122d7e83558a1b8f683ec',1,'fs_inode']]]
];
