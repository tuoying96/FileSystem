var searchData=
[
  ['image_5fcreate',['image_create',['../image_8c.html#a06e26aac40951a533b9486da0b6a0317',1,'image_create(char *path):&#160;image.c'],['../image_8h.html#a06e26aac40951a533b9486da0b6a0317',1,'image_create(char *path):&#160;image.c']]],
  ['image_5ffail',['image_fail',['../image_8c.html#a0d6a42147ee18afa1ed0d9d4e0308c2c',1,'image.c']]],
  ['init_5fnew_5finode',['init_new_inode',['../fs__util__file_8c.html#aa50635cdc05634f43907a2cf8bd910e1',1,'init_new_inode(mode_t mode, unsigned ftype):&#160;fs_util_file.c'],['../fs__util__file_8h.html#aa50635cdc05634f43907a2cf8bd910e1',1,'init_new_inode(mode_t mode, unsigned ftype):&#160;fs_util_file.c']]],
  ['is_5fdir_5fempty',['is_dir_empty',['../fs__util__dir_8c.html#adbe64a14196782e3a8c5ea8aec7f896c',1,'is_dir_empty(int inum):&#160;fs_util_dir.c'],['../fs__util__dir_8h.html#adbe64a14196782e3a8c5ea8aec7f896c',1,'is_dir_empty(int inum):&#160;fs_util_dir.c']]],
  ['is_5ffree_5fblk',['is_free_blk',['../fs__util__meta_8c.html#a29aef36b4b527520774c1fd4cdddfdaa',1,'is_free_blk(int blkno):&#160;fs_util_meta.c'],['../fs__util__meta_8h.html#a29aef36b4b527520774c1fd4cdddfdaa',1,'is_free_blk(int blkno):&#160;fs_util_meta.c']]],
  ['is_5ffree_5finode',['is_free_inode',['../fs__util__meta_8c.html#a43bc64568718037bc00908c4cb1c9cab',1,'is_free_inode(int inum):&#160;fs_util_meta.c'],['../fs__util__meta_8h.html#a43bc64568718037bc00908c4cb1c9cab',1,'is_free_inode(int inum):&#160;fs_util_meta.c']]]
];
