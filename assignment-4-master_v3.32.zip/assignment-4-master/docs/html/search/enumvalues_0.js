var searchData=
[
  ['bits_5fper_5fblk',['BITS_PER_BLK',['../fsx600_8h.html#a61dadd085c1777f559549e05962b2c9eac676a6e35862d6b48f75cefd145010f4',1,'fsx600.h']]],
  ['block_5fsize',['BLOCK_SIZE',['../blkdev_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba289ec7492eb0ef6bf5285fb142203e11',1,'blkdev.h']]]
];
