var searchData=
[
  ['block_5fmap',['block_map',['../structext2__fs.html#a2c8f1da676b43b769185d47ea830e411',1,'ext2_fs::block_map()'],['../mktest_8c.html#a2ac18ab9cca98b1d883d51b34be1bf84',1,'block_map():&#160;mktest.c']]],
  ['block_5fmap_5fbase',['block_map_base',['../structext2__fs.html#aaafa8984eed7a5a51ebc996a907eebde',1,'ext2_fs']]],
  ['block_5fmap_5fsz',['block_map_sz',['../structfs__super.html#a6d61e3b48439ba04327070b063a8a10d',1,'fs_super']]]
];
