var searchData=
[
  ['main',['main',['../_c_make_c_compiler_id_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;CMakeCCompilerId.c'],['../misc_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main(int argc, char **argv):&#160;misc.c'],['../mkfs-x6_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main(int argc, char **argv):&#160;mkfs-x6.c'],['../mktest_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main(int argc, char **argv):&#160;mktest.c'],['../read-img_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main(int argc, char **argv):&#160;read-img.c']]],
  ['mark_5finode',['mark_inode',['../fs__util__meta_8c.html#ab9fed230e1dc6b73fc634d9e85a40ee1',1,'mark_inode(int inum):&#160;fs_util_meta.c'],['../fs__util__meta_8h.html#ab9fed230e1dc6b73fc634d9e85a40ee1',1,'mark_inode(int inum):&#160;fs_util_meta.c']]]
];
