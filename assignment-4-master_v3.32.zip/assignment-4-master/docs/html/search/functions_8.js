var searchData=
[
  ['set_5fdir_5fentry',['set_dir_entry',['../fs__util__dir_8c.html#a837508b1f9fc2a09a7ccfcbeed640b8e',1,'set_dir_entry(struct fs_dirent *de, int inum, const char *name):&#160;fs_util_dir.c'],['../fs__util__dir_8h.html#a837508b1f9fc2a09a7ccfcbeed640b8e',1,'set_dir_entry(struct fs_dirent *de, int inum, const char *name):&#160;fs_util_dir.c']]],
  ['split',['split',['../split_8c.html#a307c079b0d60207df8a1054b2e41ab83',1,'split(const char *str, char *toks[], int ntoks, const char *delim):&#160;split.c'],['../split_8h.html#ac95032c4fd3095de21fd4a9f7ea549ce',1,'split(const char *p, char *toks[], int ntoks, const char *delim):&#160;split.c']]],
  ['strdup',['strdup',['../image_8c.html#a5b35572f751b50eef956a2d054ee48c0',1,'strdup(const char *):&#160;image.c'],['../misc_8c.html#a2c4f14c424a31db9c57fd046c3b9f0df',1,'strdup(const char *str):&#160;misc.c']]]
];
