var searchData=
[
  ['gid',['gid',['../structfs__inode.html#a93b1c3bdde3437a4dbfe538ffe47dc01',1,'fs_inode']]]
];
