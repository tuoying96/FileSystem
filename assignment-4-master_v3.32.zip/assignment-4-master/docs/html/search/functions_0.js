var searchData=
[
  ['check_5fdirectory',['check_directory',['../read-img_8c.html#a965d9aabe22c94107fa11a0faddb0b12',1,'read-img.c']]],
  ['check_5fdirectory_5fblock',['check_directory_block',['../read-img_8c.html#aba5411d5cc01cb07bff456a794ea82ac',1,'read-img.c']]]
];
