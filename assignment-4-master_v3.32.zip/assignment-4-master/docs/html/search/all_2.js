var searchData=
[
  ['bits_5fper_5fblk',['BITS_PER_BLK',['../fsx600_8h.html#a61dadd085c1777f559549e05962b2c9eac676a6e35862d6b48f75cefd145010f4',1,'fsx600.h']]],
  ['blkdev',['blkdev',['../structblkdev.html',1,'']]],
  ['blkdev_2eh',['blkdev.h',['../blkdev_8h.html',1,'']]],
  ['blkdev_5fops',['blkdev_ops',['../structblkdev__ops.html',1,'']]],
  ['block_5fmap',['block_map',['../structext2__fs.html#a2c8f1da676b43b769185d47ea830e411',1,'ext2_fs::block_map()'],['../mktest_8c.html#a2ac18ab9cca98b1d883d51b34be1bf84',1,'block_map():&#160;mktest.c']]],
  ['block_5fmap_5fbase',['block_map_base',['../structext2__fs.html#aaafa8984eed7a5a51ebc996a907eebde',1,'ext2_fs']]],
  ['block_5fmap_5fsz',['block_map_sz',['../structfs__super.html#a6d61e3b48439ba04327070b063a8a10d',1,'fs_super']]],
  ['block_5fsize',['BLOCK_SIZE',['../blkdev_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba289ec7492eb0ef6bf5285fb142203e11',1,'blkdev.h']]]
];
