var searchData=
[
  ['valid',['valid',['../structfs__dirent.html#ac18077e9015176ebe00d8ed141908985',1,'fs_dirent']]]
];
