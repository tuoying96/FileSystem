var fs__util__meta_8c =
[
    [ "flush_metadata", "fs__util__meta_8c.html#ae11c96c2ecf621e9d923758c2da590f0", null ],
    [ "get_free_blk", "fs__util__meta_8c.html#a46cc95d8801478c2477c7bcfeb99550f", null ],
    [ "get_free_inode", "fs__util__meta_8c.html#a3464dfb7bcf0b34a8c5301fd490c92a9", null ],
    [ "is_free_blk", "fs__util__meta_8c.html#a29aef36b4b527520774c1fd4cdddfdaa", null ],
    [ "is_free_inode", "fs__util__meta_8c.html#a43bc64568718037bc00908c4cb1c9cab", null ],
    [ "mark_inode", "fs__util__meta_8c.html#ab9fed230e1dc6b73fc634d9e85a40ee1", null ],
    [ "return_blk", "fs__util__meta_8c.html#acfe45a70596b108df154b0b334e7c403", null ],
    [ "return_inode", "fs__util__meta_8c.html#a4fbc24e517d393a57184761c3572fb32", null ]
];