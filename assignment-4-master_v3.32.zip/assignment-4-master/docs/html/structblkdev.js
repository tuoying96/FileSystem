var structblkdev =
[
    [ "ops", "structblkdev.html#a1b85c90a21de8501bf345a78d301cbcb", null ],
    [ "private", "structblkdev.html#a8291273df26175eb79758fbbc2365675", null ]
];