var fs__util__path_8h =
[
    [ "get_inode_of_path", "fs__util__path_8h.html#a77d19c62b3b44431278bfecad82c012a", null ],
    [ "get_inode_of_path_dir", "fs__util__path_8h.html#af1f5e295c71a84eabee82a8d786ddcdd", null ],
    [ "PATH_DELIM", "fs__util__path_8h.html#ae03d4fd367c0004c5c6336f253ecf656", null ]
];